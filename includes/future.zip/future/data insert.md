-- Insert Properties
INSERT INTO properties (id, title, description, property_type, city, price_per_night, max_guests, rating, main_image_url) VALUES
(1, 'Serene Beachfront Villa', 'Experience coastal bliss in this stunning villa offering direct beach access, breathtaking ocean vistas, and modern amenities. Perfect for families or groups seeking a tranquil escape with luxury comforts.', 'Villa', 'Goa', 15000, 6, 4.8, 'assets/images/property1.jpg'),
(2, 'Modern City Apartment', 'A stylish apartment in the heart of the city, perfect for business or leisure.', 'Apartment', 'Mumbai', 8000, 4, 4.5, 'assets/images/property2.jpg'),
(3, 'Cozy Mountain Homestay', 'Escape to this peaceful homestay in the mountains, with breathtaking views and fresh air.', 'Homestay', 'Manali', 5000, 3, 4.9, 'assets/images/property3.jpg'),
(4, 'Luxury Goa Villa with Pool', 'Indulge in this expansive luxury villa in Goa. Featuring a stunning private pool, lush gardens, spacious interiors, and top-tier amenities for an unforgettable holiday.', 'Villa', 'Goa', 25000, 8, 5.0, 'assets/images/property4.jpg'),
(5, 'Urban Studio in Mumbai', 'A compact and modern studio apartment, ideal for solo travelers.', 'Apartment', 'Mumbai', 6000, 2, 4.2, 'assets/images/property2.jpg');

-- Insert Property Images
INSERT INTO property_images (property_id, image_url) VALUES
(1, 'assets/images/property1.jpg'),
(1, 'assets/images/villa-interior1.jpg'),
(1, 'assets/images/luxury-pool1.jpg'),
(4, 'assets/images/property4.jpg'),
(4, 'assets/images/luxury-pool1.jpg'),
(4, 'assets/images/villa-bedroom1.jpg');

UPDATE properties
SET 
    nearest_airport = CASE 
        WHEN id % 3 = 0 THEN 'Indira Gandhi International Airport'
        WHEN id % 3 = 1 THEN 'Chhatrapati Shivaji Maharaj Airport'
        ELSE 'Kempegowda International Airport'
    END,
    nearest_landmark = CASE 
        WHEN id % 4 = 0 THEN 'India Gate'
        WHEN id % 4 = 1 THEN 'Gateway of India'
        WHEN id % 4 = 2 THEN 'Mysore Palace'
        ELSE 'Charminar'
    END,
    nearest_tourist_spot = CASE 
        WHEN id % 5 = 0 THEN 'Goa Beach'
        WHEN id % 5 = 1 THEN 'Ajanta Caves'
        WHEN id % 5 = 2 THEN 'Taj Mahal'
        WHEN id % 5 = 3 THEN 'Kerala Backwaters'
        ELSE 'Hampi Ruins'
    END;

-- Insert Amenities
INSERT INTO amenities (id, name) VALUES
(1, 'Wi-Fi'),
(2, 'Swimming Pool'),
(3, 'Air Conditioning'),
(4, 'Parking'),
(5, 'Pet Friendly'),
(6, 'Kitchen'),
(7, 'Beach Access'),
(8, 'Private Chef option'),
(9, 'Garden');

-- Insert Property Amenities
INSERT INTO property_amenities (property_id, amenity_id) VALUES
-- Property 1
(1, 1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),
-- Property 2
(2,1),(2,3),
-- Property 3
(3,1),(3,4),(3,5),
-- Property 4
(4,1),(4,2),(4,3),(4,4),(4,8),(4,9),
-- Property 5
(5,1),(5,3),(5,5);

-- Insert Reviews
INSERT INTO reviews (property_id, name, rating, comment, review_date) VALUES
(1, 'Rohan Sharma', 5, 'Absolutely stunning villa! The beach access was incredible.', '2025-09-15'),
(1, 'Priya Mehta', 4, 'Great location and beautiful views. Pool could be cleaner.', '2025-08-22'),
(4, 'Aditi Rao', 5, 'Pure luxury! Worth every penny. The pool area is fantastic.', '2025-09-25');