-- Table to define collections
CREATE TABLE collections (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,       -- e.g., "Workation-Friendly Stays"
    description VARCHAR(255) NULL,    -- short description
    image_url VARCHAR(255) NULL       -- cover image for collection
);

-- Linking table: which properties belong to which collection
CREATE TABLE collection_properties (
    collection_id INT NOT NULL,
    property_id INT NOT NULL,
    PRIMARY KEY(collection_id, property_id),
    FOREIGN KEY (collection_id) REFERENCES collections(id) ON DELETE CASCADE,
    FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE CASCADE
);
INSERT INTO collections (name, description, image_url) VALUES
('Workation-Friendly Stays', 'Perfect for working travelers with fast Wi-Fi and quiet spaces', 'images/workation.jpg'),
('Luxury Getaways', 'High-end properties for an indulgent vacation', 'images/luxury.jpg'),
('Family-Friendly Homes', 'Safe and spacious homes for family trips', 'images/family.jpg');

-- Example: assign some property IDs to collections
INSERT INTO collection_properties (collection_id, property_id) VALUES
(1, 2),
(1, 5),
(2, 3),
(2, 7),
(3, 1),
(3, 4);

--1.2 
CREATE TABLE properties (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    city VARCHAR(100),
    property_type VARCHAR(100),
    price_per_night DECIMAL(10,2),
    max_guests INT DEFAULT 1,
    main_image_url VARCHAR(255),
    video_url VARCHAR(255), -- for uploaded property videos
    latitude DECIMAL(10,7), -- for map location
    longitude DECIMAL(10,7), -- for map location
    nearest_airport VARCHAR(150),
    nearest_landmark VARCHAR(150),
    nearest_tourist_spot VARCHAR(150),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO property_images (property_id, image_url) VALUES
(1, 'assets/images/property1.jpg'),
(1, 'assets/images/villa-interior1.jpg'),
(1, 'assets/images/luxury-pool1.jpg'),
(4, 'assets/images/property4.jpg'),
(4, 'assets/images/luxury-pool1.jpg'),
(4, 'assets/images/villa-bedroom1.jpg');
UPDATE properties
SET 
    nearest_airport = CASE 
        WHEN id % 3 = 0 THEN 'Indira Gandhi International Airport'
        WHEN id % 3 = 1 THEN 'Chhatrapati Shivaji Maharaj Airport'
        ELSE 'Kempegowda International Airport'
    END,
    nearest_landmark = CASE 
        WHEN id % 4 = 0 THEN 'India Gate'
        WHEN id % 4 = 1 THEN 'Gateway of India'
        WHEN id % 4 = 2 THEN 'Mysore Palace'
        ELSE 'Charminar'
    END,
    nearest_tourist_spot = CASE 
        WHEN id % 5 = 0 THEN 'Goa Beach'
        WHEN id % 5 = 1 THEN 'Ajanta Caves'
        WHEN id % 5 = 2 THEN 'Taj Mahal'
        WHEN id % 5 = 3 THEN 'Kerala Backwaters'
        ELSE 'Hampi Ruins'
    END;