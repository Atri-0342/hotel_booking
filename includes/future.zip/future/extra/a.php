<?php
session_name("ADMIN_SESSION");
session_start();

// Redirect if admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - QOZY</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
         :root {
            --primary-purple: #a999d1;
            --accent-blue: #a0e6ff;
            --text-dark: #333;
            --text-light: #555;
            --background-light: #f4f4f9;
            --container-bg: #ffffff;
            --border-color: #ddd;
            --sidebar-bg: #343a40;
            --sidebar-link: #adb5bd;
            --sidebar-link-hover: #ffffff;
         }
         body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--background-light);
            margin: 0;
            display: flex;
            min-height: 100vh;
         }
         .admin-sidebar {
            flex: 0 0 250px;
            background-color: var(--sidebar-bg);
            color: white;
            padding: 20px;
            box-sizing: border-box;
         }
         .admin-sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 1.5rem;
            color: var(--accent-blue);
         }
         .admin-sidebar nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
         }
         .admin-sidebar nav li { margin-bottom: 15px; }
         .admin-sidebar nav a {
            color: var(--sidebar-link);
            text-decoration: none;
            font-size: 1.1rem;
            display: block;
            padding: 10px 15px;
            border-radius: 6px;
            transition: background-color 0.3s, color 0.3s;
         }
         .admin-sidebar nav a i {
            margin-right: 10px;
            width: 20px;
         }
         .admin-sidebar nav a:hover,
         .admin-sidebar nav a.active {
            background-color: rgba(255, 255, 255, 0.1);
            color: var(--sidebar-link-hover);
         }
         .admin-main-content {
            flex-grow: 1;
            padding: 30px;
            overflow-y: auto;
            box-sizing: border-box;
         }
         .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
         }
         .admin-header h1 {
            margin: 0;
            color: var(--text-dark);
         }
         .admin-header .logout-btn {
            background-color: var(--primary-purple);
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            transition: background-color 0.3s;
         }
         .admin-header .logout-btn:hover {
            background-color: #907fbf;
         }
         .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 25px;
         }
         .stat-card {
            background-color: var(--container-bg);
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.07);
            text-align: center;
         }
         .stat-card i {
            font-size: 2.5rem;
            color: var(--primary-purple);
            margin-bottom: 15px;
         }
         .stat-card .stat-number {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 5px;
         }
         .stat-card .stat-label {
            font-size: 1rem;
            color: var(--text-light);
         }
         @media (max-width: 768px) {
            body { flex-direction: column; }
            .admin-sidebar { width: 100%; }
         }
    </style>
</head>
<body>
    <aside class="admin-sidebar">
        <h2>QOZY Admin</h2>
        <nav>
            <ul>
                <li><a href="index.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="users.php"><i class="fas fa-users"></i> User Management</a></li>
                <li><a href="properties.php"><i class="fas fa-hotel"></i> Listing Management</a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> Booking Management</a></li>
                <li><a href="reviews.php"><i class="fas fa-star"></i> Review Management</a></li>
                <li><a href="support.php"><i class="fas fa-envelope"></i> Support Messages</a></li>
            </ul>
        </nav>
    </aside>

    <main class="admin-main-content">
        <header class="admin-header">
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></h1>
            <a href="admin_logout.php" class="logout-btn">Logout</a>
        </header>

        <section class="stats-grid">
            <div class="stat-card">
                <i class="fas fa-users"></i>
                <div id="stat-users" class="stat-number">...</div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-hotel"></i>
                <div id="stat-properties" class="stat-number">...</div>
                <div class="stat-label">Total Properties</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-calendar-check"></i>
                <div id="stat-bookings" class="stat-number">...</div>
                <div class="stat-label">Total Bookings</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-wallet"></i>
                <div id="stat-revenue" class="stat-number">...</div>
                <div class="stat-label">Estimated Revenue</div>
            </div>
        </section>

        <section style="margin-top: 40px; background-color: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.07);">
             <h2>Recent Activity</h2>
             <p>This area can show recent bookings, new user registrations, etc.</p>
        </section>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('stat-users').textContent = Math.floor(Math.random() * 500) + 50;
            document.getElementById('stat-properties').textContent = Math.floor(Math.random() * 100) + 10;
            document.getElementById('stat-bookings').textContent = Math.floor(Math.random() * 1000) + 100;
            document.getElementById('stat-revenue').textContent = `₹${(Math.random() * 500000 + 50000).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
        });
    </script>
</body>
</html>
