<?php
session_start();

// Check if the user is logged in. If not, redirect to the login page.
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Use htmlspecialchars to prevent XSS attacks
$user_name = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QOZY Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Simple styles for the dashboard */
        .dashboard-container {
            text-align: center;
            padding: 50px;
        }
        .dashboard-container h1 {
            color: var(--text-dark);
            margin-bottom: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 30px;
            padding: 10px 20px;
            background-color: var(--primary-purple);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }
        .logout-link:hover {
            background-color: var(--btn-hover);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h1>Welcome, <?php echo $user_name; ?>!</h1>
        <p>You have successfully logged in to your QOZY dashboard.</p>
        <p>From here, you will be able to manage your profile and view your bookings.</p>
        <a href="logout.php" class="logout-link">Logout</a>
    </div>
</body>
</html>