<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QOZY - Find Your Perfect Holiday Home</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

    <header class="main-header">
        <div class="container">
            <a href="index.php" class="logo-link">
                <img src="assets/images/Logo-QOZY.png" class="logo-image">
            </a>
            <nav class="main-nav">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                    <a href="logout.php" class="nav-link btn-nav">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="nav-link btn-nav-secondary">Login</a>
                    <a href="register.php" class="nav-link btn-nav">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main class="hero-section">
        <div class="hero-content-wrapper">

            <div class="hero-text">
                <h1 class="hero-title">Find Your Perfect Holiday Home</h1>
                <p class="hero-subtitle">Book your next cozy stay with QOZY</p>
            </div>
            
            <form action="search_results.php" method="GET" class="search-form">
                <div class="search-input-group">
                    <i class="fas fa-map-marker-alt"></i>
                    <input type="text" name="destination" placeholder="Enter a city or destination" required>
                </div>
                <div class="search-input-group">
                    <i class="fas fa-calendar-alt"></i>
                    <input type="text" name="checkin" placeholder="Check-in Date" 
                        onfocus="(this.type='date')" onblur="(this.type='text')" required>
                </div>
                <div class="search-input-group">
                    <i class="fas fa-calendar-alt"></i>
                    <input type="text" name="checkout" placeholder="Check-out Date" 
                        onfocus="(this.type='date')" onblur="(this.type='text')" required>
                </div>
                <div class="search-input-group">
                    <i class="fas fa-users"></i>
                    <input type="number" name="guests" placeholder="Guests" min="1" required>
                </div>
                <button type="submit" class="search-btn">
                    <i class="fas fa-search"></i> Search
                </button>
            </form>

        </div>
    </main>

    <script src="assets/js/homepage-search.js"></script>
</body>
</html>
