<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details - QOZY</title> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
    /* --- CSS VARIABLES --- */
    :root {
        --primary-purple: #a999d1;
        --accent-pink: #ffc0cb;
        --text-dark: #333;
        --text-light: #777;
        --background-light: #f4f4f9;
        --container-bg: #fff;
        --border-color: #ddd;
        --btn-primary-bg: #a999d1;
        --btn-primary-hover: #ffc0cb;
    }

    html, body { height: auto; overflow-y: auto; margin:0; padding:0; font-family: 'Poppins', sans-serif; }
    body.details-page-body { background-color: var(--background-light); }

    .property-details-container { width: 90%; max-width: 1100px; margin: 20px auto; padding-top: 70px; }

    /* Header */
    .property-header { margin-bottom: 30px; }
    .property-header h1 { font-size: 2.8rem; color: var(--text-dark); margin-bottom: 15px; }
    .property-meta { font-size: 1.1rem; color: var(--text-light); display: flex; flex-wrap: wrap; gap: 15px; align-items: center; }
    .property-meta i { color: var(--primary-purple); margin-right: 5px; }
    #property-rating i.fa-star { color: var(--accent-pink); }
    #property-type-header { font-weight: 600; }

    /* Gallery */
    .property-gallery { margin-bottom: 40px; border-radius: 15px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
    .gallery-main-image img { display: block; width: 100%; height: 500px; object-fit: cover; }

    /* Layout */
    .details-layout { display: flex; gap: 50px; align-items: flex-start; }
    .details-main-content { flex-grow: 1; overflow: visible; }
    .details-main-content section { margin-bottom: 40px; padding-bottom: 30px; border-bottom: 1px solid var(--border-color); }
    .details-main-content section:last-child { border-bottom: none; }
    .details-main-content h2 { font-size: 1.8rem; color: var(--text-dark); margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
    .details-main-content h2 i { color: var(--primary-purple); font-size: 1.5rem; }

    /* Amenities */
    #amenities-list { list-style: none; padding:0; margin:0; display:grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 15px 20px; }
    #amenities-list li { display:flex; align-items:center; font-size:1rem; color: var(--text-dark); }
    #amenities-list li i { color: var(--primary-purple); font-size:1.2rem; width:30px; text-align:center; margin-right:15px; }

    /* Reviews */
    .reviews-summary { margin-bottom:25px; }
    .reviews-summary h2 { margin-bottom:0; font-size:1.6rem; }
    .reviews-summary i.fa-star { color: var(--accent-pink); }
    #reviews-list { display:flex; flex-direction:column; gap:25px; }
    .review-item { border:1px solid var(--border-color); padding:20px; border-radius:10px; background-color: var(--container-bg); }
    .review-header { display:flex; justify-content:space-between; margin-bottom:10px; }
    .reviewer-name { font-weight:700; color: var(--text-dark); }
    .review-date { font-size:0.9rem; color: var(--text-light); }
    .review-rating i.fa-star { color: var(--accent-pink); font-size:1rem; }
    .review-body { color: var(--text-dark); line-height:1.6; }

    /* Booking Box */
    .booking-box { flex:0 0 340px; background-color: var(--container-bg); padding:30px; border-radius:12px; box-shadow:0 8px 25px rgba(0,0,0,0.1); align-self:flex-start; position: sticky; top:100px; }
    .booking-price { font-size:1.2rem; color: var(--text-dark); margin-bottom:5px; text-align:left; }
    .booking-price strong { font-size:1.6rem; color: var(--primary-purple); font-weight:700; }
    .booking-rating { font-size:0.9rem; color: var(--text-light); margin-bottom:20px; text-align:left; }
    .booking-rating i.fa-star { color: var(--accent-pink); margin-right:3px; }
    .booking-form { border-top:1px solid var(--border-color); padding-top:20px; }
    .booking-dates { display:flex; gap:10px; margin-bottom:15px; }
    .booking-box input[type="date"], .booking-box input[type="number"] { width:100%; padding:12px; border:1px solid var(--border-color); border-radius:8px; box-sizing:border-box; font-size:0.9rem; margin-bottom:15px; }
    .booking-box input[type="date"] { color: var(--text-light); }
    .booking-box input[type="date"]:focus, .booking-box input[type="date"]:valid { color: var(--text-dark); }

    .btn-book { width:100%; padding:14px; background-color: var(--btn-primary-bg); color:white; border:none; border-radius:8px; font-size:1.1rem; font-weight:700; cursor:pointer; transition:0.3s; }
    .btn-book:hover { background-color: var(--btn-primary-hover); }
    .booking-note { font-size:0.85rem; text-align:center; color: var(--text-light); margin-top:15px; }

    /* Responsive */
    @media (max-width: 992px) { .details-layout { flex-direction: column; } .booking-box { width:100%; position:static; margin-top:20px; } .property-details-container { width:95%; } }
    @media (max-width: 768px) { .property-header h1 { font-size:2.2rem; } .details-main-content h2 { font-size:1.5rem; } .property-gallery img { height:350px; } #amenities-list { grid-template-columns:1fr; } }
    a.property-card-link { text-decoration:none; }
    </style>
</head>

<body class="details-page-body"> 
<?php 
session_start(); 
$isLoggedIn = isset($_SESSION['user_id']);
$user_name = $isLoggedIn ? htmlspecialchars($_SESSION['user_name']) : 'Guest';
include 'includes/header.php'; 
?>

<main class="page-wrapper property-details-container">
    <section class="property-header">
        <h1 id="property-title">Loading Property Name...</h1>
        <div class="property-meta">
            <span id="property-rating"><i class="fas fa-star"></i> ...</span>
            <span>·</span>
            <span id="property-location"><i class="fas fa-map-marker-alt"></i> ..., ...</span>
            <span>·</span>
            <span id="property-type-header">Loading Type...</span>
        </div>
    </section>

    <section class="property-gallery">
        <div class="gallery-main-image">
            <img id="main-property-image" src="assets/images/placeholder.jpg" alt="Property image">
        </div>
    </section>

    <div class="details-layout">
        <div class="details-main-content">
            <section class="property-description">
                <h2>About this space</h2>
                <p id="property-description">Loading details...</p>
            </section>

            <section class="property-amenities">
                <h2>What this place offers</h2>
                <ul id="amenities-list">
                    <li><i class="fas fa-spinner fa-spin"></i> Loading amenities...</li>
                </ul>
            </section>

            <section class="property-reviews">
                <div class="reviews-summary">
                    <h2><i class="fas fa-star"></i> <span id="avg-rating">...</span> (<span id="review-count">...</span> reviews)</h2>
                </div>
                <div id="reviews-list">
                    <p>Loading reviews...</p>
                </div>
            </section>
        </div>

        <aside class="booking-box">
            <p class="booking-price"><strong id="property-price">₹...</strong> / night</p>
            <div class="booking-rating">
                <span id="booking-rating-stars"><i class="fas fa-star"></i> ...</span> 
                (<span id="booking-review-count">...</span> reviews)
            </div>
            <div class="booking-form">
                <div class="booking-dates">
                    <input type="date" placeholder="Check-in" id="booking-checkin">
                    <input type="date" placeholder="Check-out" id="booking-checkout">
                </div>
                <input type="number" placeholder="Guests" min="1" id="booking-guests">
                <?php if($isLoggedIn): ?>
                    <button class="btn btn-book">Request to Book</button>
                    <p class="booking-note">You won't be charged yet</p>
                <?php else: ?>
                    <p class="booking-note">Please <a href="login.php">Login</a> or <a href="register.php">Register</a> to book this property.</p>
                <?php endif; ?>
            </div>
        </aside>
    </div>
</main>

<script src="assets/js/fake-data.js"></script>
<script src="assets/js/property-details.js"></script> 
</body>
</html>
