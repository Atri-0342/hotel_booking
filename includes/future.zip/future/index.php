<?php
session_start();
require 'includes/db_connect.php'; // PDO connection

// Check login
$isLoggedIn = isset($_SESSION['user_id']);
$user_name = $isLoggedIn ? htmlspecialchars($_SESSION['user_name']) : 'Guest';
$user_city = '';

// Fetch user's city if logged in
if ($isLoggedIn) {
    $stmt = $pdo->prepare("SELECT city FROM users WHERE id=?");
    $stmt->execute([$_SESSION['user_id']]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $user_city = $row ? $row['city'] : '';
}

// Theme colors
$primary_purple = '#a999d1';
$accent_pink = '#ffc0cb';
$text_dark = '#fff';
$background_light = '#f4f4f9';

// Fetch offers
$stmt = $pdo->query("SELECT * FROM offers ORDER BY id DESC");
$offers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch properties near user's city (limit 6)
if ($user_city) {
    $stmt = $pdo->prepare("SELECT * FROM properties ORDER BY id DESC LIMIT 6");
    $stmt->execute([$user_city]);
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $stmt = $pdo->query("SELECT * FROM properties ORDER BY id DESC LIMIT 6");
    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Add first image to each property
foreach ($properties as &$prop) {
    $stmtImg = $pdo->prepare("SELECT image_url FROM property_images WHERE property_id=? LIMIT 1");
    $stmtImg->execute([$prop['id']]);
    $img = $stmtImg->fetch();
    $prop['image'] = $img ? $img['image_url'] : $prop['main_image_url'];
}
unset($prop);

// Fetch themed collections
$collectionsStmt = $pdo->query("
    SELECT c.id, c.name, c.description, c.image_url,
           GROUP_CONCAT(p.id) AS property_ids
    FROM collections c
    LEFT JOIN collection_properties cp ON c.id = cp.collection_id
    LEFT JOIN properties p ON cp.property_id = p.id
    GROUP BY c.id
");
$collections = $collectionsStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>QOZY Dashboard</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body { margin:0; font-family:'Segoe UI', sans-serif; background: <?= $background_light ?>; }

/* Welcome Box */
.welcome-box { 
    background:url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80') center/cover no-repeat; 
    color:<?= $text_dark ?>; text-align:center; padding:60px 20px; border-radius:12px; margin:20px auto; max-width:1100px; position:relative; box-shadow:0 2px 10px rgba(0,0,0,0.1);
}
.welcome-box::after { 
    content:''; position:absolute; top:0; left:0; right:0; bottom:0; background:rgba(0,0,0,0.4); border-radius:12px; pointer-events:none; 
}
.welcome-box h1,.welcome-box p{position:relative; z-index:1;}
.welcome-box h1{font-size:2rem;margin-bottom:10px;}
.welcome-box p{font-size:1rem;}

/* Search Form */
.hero-section { margin-top:30px; }
.search-form { display:flex; justify-content:center; gap:10px; flex-wrap:wrap; }
.search-form input[type=text] { width:400px; padding:15px 20px; border-radius:8px; border:1px solid #ccc; font-size:1.1rem; }
.search-form button { padding:15px 30px; font-size:1.1rem; border-radius:8px; border:none; background:#a0e6ff; cursor:pointer; display:flex; align-items:center; gap:8px; }
.search-form button:hover { background:#78d4ff; transform:scale(1.05); }

/* Offers Section */
.offers-section, .collections-section, .properties-section { width:95%; max-width:1200px; margin:40px auto; }
.offers-section h2, .collections-section h2, .properties-section h2 { text-align:center; color: <?= $primary_purple ?>; margin-bottom:20px; font-size:2rem; }

/* Offers Grid */
.offers-container { display:flex; gap:20px; overflow-x:auto; padding-bottom:10px; }
.offer-card { 
    flex:0 0 260px; height:200px; border-radius:16px; padding:10px 20px; display:flex; flex-direction:column; align-items:center; text-align:center; transition:0.3s; position:relative; 
    background-size:cover; background-position:center; box-shadow:0 4px 12px rgba(0,0,0,0.2);
}
.offer-card::after { 
    content:''; position:absolute; top:0; left:0; right:0; bottom:0; background:linear-gradient(to top, rgba(0,0,0,0.6), rgba(0,0,0,0.2)); border-radius:16px; 
}
.offer-card i, .offer-card h4, .offer-card p{position:relative; z-index:1; color:white;}
.offer-card i{ font-size:2rem; margin-bottom:10px; }
.offer-card h4{ margin:5px 0; font-size:1.2rem; font-weight:600; }
.offer-card p{ font-size:0.95rem; }
.offer-card:hover { transform:translateY(-8px) scale(1.05); box-shadow:0 10px 20px rgba(0,0,0,0.3); }

/* Themed Collections Grid */
.collections-grid { display:flex; gap:20px; flex-wrap:wrap; justify-content:center; }
.collection-card { position:relative; width:300px; height:200px; border-radius:12px; overflow:hidden; color:#fff; text-decoration:none; display:flex; align-items:flex-end; padding:15px; transition:0.3s; }
.collection-card:hover { transform:scale(1.05); box-shadow:0 8px 20px rgba(0,0,0,0.3); }
.collection-card .overlay { background:rgba(0,0,0,0.4); width:100%; height:100%; position:absolute; top:0; left:0; border-radius:12px; }
.collection-card h3, .collection-card p { position:relative; z-index:1; }

/* Properties Grid */
.properties-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(250px,1fr)); gap:20px; }
.property-card { background:#fff; border-radius:8px; overflow:hidden; box-shadow:0 4px 12px rgba(0,0,0,0.1); transition:0.2s; }
.property-card:hover { transform:translateY(-4px); box-shadow:0 6px 16px rgba(0,0,0,0.15); }
.property-card img { width:100%; height:160px; object-fit:cover; }
.property-card .card-content { padding:15px; }
.property-card h3{margin:0 0 8px;font-size:1.1rem;}
.property-card p{margin:4px 0;color:#555;font-size:0.95rem;}
.property-card .rating i{color:#f5a623;}
.property-card-link{text-decoration:none;color:inherit; display:block;}

/* Footer */
footer { text-align:center; padding:25px; color:#555; margin-top:50px; font-size:0.95rem; }
footer a { color: <?= $primary_purple ?>; text-decoration:none; font-weight:600; }
footer a:hover { text-decoration:underline; }

/* Responsive */
@media(max-width:768px){ .search-form input[type=text]{ width:250px; } .offer-card{ flex:0 0 200px; height:180px; } .collection-card{ width:45%; height:180px;} }
@media(max-width:480px){ .search-form input[type=text]{ width:180px; } .offer-card{ flex:0 0 160px; height:160px; } .collection-card{ width:100%; height:160px;} }
</style>
</head>
<body>

<?php include 'includes/header.php'; ?>

<!-- Welcome + Search -->
<div class="welcome-box">
    <h1>Welcome, <?= $user_name ?>!</h1>
    <p>Explore properties near you and check our latest offers.</p>
    <div class="hero-section">
        <form action="search_results.php" method="GET" class="search-form">
            <input type="text" name="query" placeholder="Search properties, city, amenities..." required>
            <button type="submit"><i class="fas fa-search"></i> Search</button>
        </form>
    </div>
</div>

<!-- Offers Section -->
<div class="offers-section">
    <h2>Available Offers</h2>
    <div class="offers-container">
        <?php foreach($offers as $offer): ?>
            <div class="offer-card" style="background:url('<?= htmlspecialchars($offer['image_url']) ?>') center/cover no-repeat;">
                <i class="<?= $offer['icon'] ?>"></i>
                <h4><?= htmlspecialchars($offer['title']) ?></h4>
                <p><?= htmlspecialchars($offer['description']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Themed Collections Section -->
<div class="collections-section">
    <h2>Themed Collections</h2>
    <div class="collections-grid">
        <?php foreach($collections as $col): ?>
            <a href="collection_details.php?id=<?= $col['id'] ?>" class="collection-card" 
               style="background:url('<?= htmlspecialchars($col['image_url']) ?>') center/cover no-repeat;">
                <div class="overlay"></div>
                <h3><?= htmlspecialchars($col['name']) ?></h3>
                <p><?= htmlspecialchars($col['description']) ?></p>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<!-- Properties Near User -->
<div class="properties-section">
    <h2>Properties near <?= htmlspecialchars($user_city ?: 'you') ?></h2>
    <div class="properties-grid">
        <?php foreach($properties as $prop): ?>
            <a href="property_details.php?id=<?= $prop['id'] ?>" class="property-card-link">
                <div class="property-card">
                    <img src="<?= htmlspecialchars($prop['image']) ?>" alt="<?= htmlspecialchars($prop['title']) ?>">
                    <div class="card-content">
                        <div class="rating"><i class="fas fa-star"></i> <?= $prop['rating'] ?? '0' ?></div>
                        <h3><?= htmlspecialchars($prop['title']) ?></h3>
                        <p><?= htmlspecialchars($prop['city']) ?> - <?= htmlspecialchars($prop['property_type'] ?? '') ?></p>
                        <p>₹<?= number_format($prop['price_per_night']) ?> / night</p>
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<!-- Footer -->
<footer>
<p>&copy; <?= date('Y') ?> QOZY. All rights reserved. | <a href="index.php">Home</a></p>
</footer>

</body>
</html>
